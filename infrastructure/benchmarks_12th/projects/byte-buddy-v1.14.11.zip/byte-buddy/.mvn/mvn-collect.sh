./mvnw clean jacoco:prepare-agent verify jacoco:report -Pextras -Pchecks -Panalysis -Pintegration -Pchecksum-collect
